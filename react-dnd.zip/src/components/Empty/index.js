import React from 'react';
import './index.scss';

const Empty = props => {
  return (
    <div className="empty">
      <p>Empty</p>
    </div>
  );
};

export default Empty;
