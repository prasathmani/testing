import React from 'react';
import { useDrop } from 'react-dnd';
import { Box } from 'components/Box';

export const DropBox = ({ accept, droppedItem, onDrop, moveCard }) => {
  const [{ isOver, canDrop }, drop] = useDrop({
    accept,
    drop: onDrop,
    collect: monitor => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  });
  const isActive = isOver && canDrop;

  return (
    <div ref={drop} className="c-box">
      {isActive ? 'Release to drop' : `Drop Here`}

      {droppedItem &&
        droppedItem.map((item, i) => <Box name={item.name} type={item.type} key={i} moveCard={moveCard} />)}
    </div>
  );
};
