import React, { useState, useCallback } from 'react';
import { Box } from 'components/Box';
import { DropBox } from 'components/DropBox';

const ItemTypes = {
  BOXB: 'boxb',
  BOXC: 'boxc',
};

const Container = () => {
  const [dropArea, setdropArea] = useState([
    { accepts: [ItemTypes.BOXB, ItemTypes.BOXC], droppedItem: [] },
    { accepts: [ItemTypes.BOXB, ItemTypes.BOXC], droppedItem: [] },
  ]);

  const [boxes] = useState([
    {
      name: <img src="https://via.placeholder.com/300x100/0000FF/808080?Text=BOX1" alt="box1" />,
      type: ItemTypes.BOXB,
    },
    {
      name: <img src="https://via.placeholder.com/300x100/FF0000/808080?Text=BOX2" alt="box2" />,
      type: ItemTypes.BOXB,
    },
    {
      name: <img src="https://via.placeholder.com/300x100/008000/808080?Text=BOX3" alt="box3" />,
      type: ItemTypes.BOXC,
    },
  ]);

  const handleDrop = useCallback(
    (index, item) => {
      const _state = [...dropArea];
      const _droppedItem = [..._state[index].droppedItem];
      const found = _droppedItem.some(el => el.name === item.name);
      if (!found) {
        _state[index].droppedItem = [..._droppedItem, item];
        setdropArea(_state);
      }
    },
    [dropArea],
  );

  return (
    <div className="row">
      <div className="c-box c-box--source">
        {boxes.map(({ name, type }, index) => (
          <Box name={name} type={type} key={index} />
        ))}
      </div>

      {dropArea.map(({ accepts, droppedItem }, index) => (
        <DropBox accept={accepts} droppedItem={droppedItem} onDrop={item => handleDrop(index, item)} key={index} />
      ))}
    </div>
  );
};

export default Container;
