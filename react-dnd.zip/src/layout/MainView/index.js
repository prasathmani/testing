import React, { Component } from 'react';
import Header from 'components/Header';

class MainView extends Component {
  render() {
    return (
      <>
        <Header />
        <div id="content-wrapper" className="d-flex">
          <div id="content">{this.props.children}</div>
        </div>
      </>
    );
  }
}

export default MainView;
