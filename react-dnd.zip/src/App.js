import React, { Component, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { ROUTES } from 'common/constants';

import './styles/styles.scss'; // global styles

//layout import
const MainView = lazy(() => import('layout/MainView'));

const Dashboard = lazy(() => import('pages/Dashboard'));

//layout routing
const AppRoute = ({ component: Component, layout: Layout, submenu: Submenu, ...rest }) => (
  <Route
    {...rest}
    render={props => (
      <Layout submenu={Submenu ? Submenu : false}>
        <Component {...props} />
      </Layout>
    )}
  />
);

const PageLoader = () => <>Loading...</>;
const NotFound = () => <h1>404 Not Found!</h1>;

class App extends Component {
  render() {
    return (
      <Router>
        <Suspense fallback={<PageLoader />}>
          <div id="main">
            <Switch>
			<AppRoute layout={MainView} exact path="/" component={Dashboard} />
              <AppRoute layout={MainView} exact path={ROUTES.DASHBOARD} component={Dashboard} />
              <AppRoute layout={MainView} component={NotFound} />
            </Switch>
          </div>
        </Suspense>
      </Router>
    );
  }
}

export default App;
