export const ROUTES = {
  APP_ROOT: '/',
  DASHBOARD: '/dashboard',
};
