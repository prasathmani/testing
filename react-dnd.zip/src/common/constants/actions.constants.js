export const ACTIONS = {
  DRAG: 'DRAG',
  DROP: 'DROP',
};
