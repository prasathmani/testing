<?php 
session_start();
require_once 'includes/auth_validate.php';
require_once './config/config.php';
$del_id = $_POST['uid'];

//server response header
function jsonResponse($data) {
    if($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}

if ($del_id && $_SERVER['REQUEST_METHOD'] == 'POST') 
{
    $users = $del_id;
    $db = getDbInstance();
    $isSuccess = false;
    if($users) {
        foreach ($users as $user) {
            $db->where('id', $user);
            $status = $db->delete('users');
            if ($status) {
                $isSuccess = true;
            } else {
                $isSuccess = false;
                jsonResponse(array("status" => false, "message" => I18N("Unable to delete Reports")));
            }
        }
    }

    if($isSuccess) {
        jsonResponse(array("status" => true, "message" => I18N("Deleted successfully")));
    }
    
}