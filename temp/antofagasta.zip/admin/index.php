<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

//Get DB instance. function is defined in config.php
$db = getDbInstance();

//Get Dashboard information
$numUsers = $db->getValue ("users", "count(*)");
$numReviews = $db->getValue ("reviews", "count(*)");

include_once('includes/header.php');
?>
<section id="page-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header"><?php echo I18N('Dashboard'); ?></h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card text-white bg-success mb-3">
                    <div class="card-body">
                        <div class="float-left">
                            <h5 class="card-title fa-3x"> <?php echo $numUsers; ?></h5>
                            <span><?php echo I18N('No of Users'); ?></span>
                        </div>
                        <div class="float-right">
                            <i class="fa fa-user fa-5x"></i>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="user.php" class="text-white"><?php echo I18N("View Details"); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card text-white bg-warning mb-3">
                    <div class="card-body">
                        <div class="float-left">
                            <h5 class="card-title fa-3x"> <?php echo $numReviews; ?></h5>
                            <span><?php echo I18N("Total Reports"); ?></span>
                        </div>
                        <div class="float-right">
                            <i class="fas fa-file-upload fa-5x"></i>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="reviews.php" class="text-white"><?php echo I18N("View Details"); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card text-white bg-info mb-3">
                    <div class="card-body">
                        <div class="float-left">
                            <h5 class="card-title fa-3x"><?php echo I18N("Add"); ?></h5>
                            <span><?php echo I18N("New user"); ?></span>
                        </div>
                        <div class="float-right">
                            <i class="fas fa-user-plus fa-3x"></i>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="user-add.php?operation=create" class="text-white"><?php echo I18N("Create new"); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card text-white bg-danger mb-3">
                    <div class="card-body">
                        <div class="float-left">
                            <h5 class="card-title fa-3x"><?php echo I18N("Add"); ?></h5>
                            <span><?php echo I18N("New Reports"); ?></span>
                        </div>
                        <div class="float-right">
                            <i class="fas fa-cloud-upload-alt fa-3x"></i>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="review-bulk-upload.php" class="text-white"><?php echo I18N("Bulk Upload"); ?></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-8">


                <!-- /.panel -->
            </div>
            <!-- /.col-lg-8 -->
            <div class="col-lg-4">

                <!-- /.panel .chat-panel -->
            </div>
            <!-- /.col-lg-4 -->
        </div>
        <!-- /.row -->
    </div>
</section>
<!-- /#page-wrapper -->

<?php include_once('includes/footer.php'); ?>
