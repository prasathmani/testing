<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

//Get Input data from query string
$search_string = filter_input(INPUT_GET, 'search_string');
$filter_col = filter_input(INPUT_GET, 'filter_col');
$order_by = filter_input(INPUT_GET, 'order_by');

//Get current page.
$page = filter_input(INPUT_GET, 'page');

//Per page limit for pagination.
$pagelimit = 20;

if (!$page) {
    $page = 1;
}

// If filter types are not selected we show latest created data first
if (!$filter_col) {
    $filter_col = "created_on";
}
if (!$order_by) {
    $order_by = "Desc";
}

//Get DB instance. i.e instance of MYSQLiDB Library
$db = getDbInstance();
$select = array('id', 'file_name', 'file_date', 'user_rid', 'created_by', 'created_on', 'status');

//Start building query according to input parameters.
// If search string
if ($search_string) 
{
    $db->where('user_rid', '%' . $search_string . '%', 'like');
}

//If order by option selected
if ($order_by)
{
    $db->orderBy($filter_col, $order_by);
}

//Set pagination limit
$db->pageLimit = $pagelimit;

//Get result of the query.
$reviews = $db->arraybuilder()->paginate("reviews", $page, $select);
$total_pages = $db->totalPages;

// get columns for order filter
foreach ($reviews as $value) {
    foreach ($value as $col_name => $col_value) {
        $filter_options[$col_name] = $col_name;
    }
    //execute only once
    break;
}

function getFileUrl($file_name) {
    return str_replace('../', '', $file_name);
}

include_once 'includes/header.php';
?>

<!--Main container start-->
<div id="page-wrapper">
    <div class="container-fuild">
        <div class="card mt-5">
    <div class="card-header">
        <strong><?php echo I18N("Reports"); ?></strong>
        <span class="float-right">
            <button class="btn btn-danger btn-sm" id="js-delete-reports"><i class="fas fa-trash"></i> <?php echo I18N("Delete"); ?></button>
        </span>
        <a href="review-add.php?operation=create" class="float-right mr-2">
        	<button class="btn btn-success btn-sm"><i class="far fa-address-book"></i> <?php echo I18N("Add New"); ?></button>
        </a>
        <a href="review-bulk-upload.php" class="float-right mr-2">
            <button class="btn btn-success btn-sm"><i class="fas fa-upload"></i> <?php echo I18N("Bulk Upload"); ?></button>
        </a>
    </div>
    <div class="card-body">
        <?php include('./includes/flash_messages.php') ?>
    <!--    Begin filter section-->
    <div class="well text-center filter-form">
        <form class="form form-inline" action="">
            <div class="row">
                 <div class="col">
            <label for="input_search"><?php echo I18N("Search"); ?></label>
        </div>
         <div class="col">
            <input type="text" class="form-control form-control-sm" id="input_search" name="search_string" value="<?php echo htmlspecialchars($search_string, ENT_QUOTES, 'UTF-8'); ?>">
        </div>
         <div class="col">
            <label for ="input_order"><?php echo I18N("OrderBy"); ?></label>
        </div>
         <div class="col">
            <select name="filter_col" class="form-control form-control-sm">

                <?php
                foreach ($filter_options as $option) {
                    ($filter_col === $option) ? $selected = "selected" : $selected = "";
                    echo ' <option value="' . $option . '" ' . $selected . '>' . $option . '</option>';
                }
                ?>

            </select>
        </div>
         <div class="col">

            <select name="order_by" class="form-control form-control-sm" id="input_order">

                <option value="Asc" <?php
                if ($order_by == 'Asc') {
                    echo "selected";
                }
                ?> >Asc</option>
                <option value="Desc" <?php
                if ($order_by == 'Desc') {
                    echo "selected";
                }
                ?>>Desc</option>
            </select>
        </div>
         <div class="col">
            <input type="submit" value="<?php echo I18N("Go"); ?>" class="btn btn-primary btn-sm">
        </div>

        </form>
    </div>
<!--   Filter section end-->

    <hr>


    <table class="table table-striped table-bordered table-condensed">
        <thead>
            <tr>
                <th class="header">#</th>
                <th><input class="form-check-input position-static ml-0" type="checkbox" id="selectAll" value="option1" aria-label="Select All"></th>
                <th><?php echo I18N("Users"); ?></th>
                <th><?php echo I18N("File Date"); ?></th>
                <th><?php echo I18N("Uploaded By"); ?></th>
                <th><?php echo I18N("Uploaded"); ?></th>
                <th><?php echo I18N("Action"); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $ii = 1;
            foreach ($reviews as $row) : ?>
                <tr>
	                <td><?php echo $ii ?></td>
                    <td><input class="form-check-input position-static ml-0" type="checkbox" name="rid[]" id="<?php echo $ii ?>" value="<?php echo $row['id'] ?>" aria-label="select"></td>
                    <td><?php echo htmlspecialchars($row['user_rid']) ?></td>
                    <td><?php echo htmlspecialchars($row['file_date']) ?></td>
                    <td><?php echo $row['created_by']; ?></td>
                    <td><?php echo $row['created_on']; ?></td>
                    <td><a href="<?php echo '../'.htmlspecialchars(getFileUrl($row['file_name'])) ?>" download><?php echo I18N("Download"); ?></a></td>
				</tr>
            <?php
                $ii++;
                endforeach; 
            ?>      
        </tbody>
    </table>


   
<!--    Pagination links-->
    <div class="text-center">

        <?php
        if (!empty($_GET)) {
            //we must unset $_GET[page] if previously built by http_build_query function
            unset($_GET['page']);
            //to keep the query sting parameters intact while navigating to next/prev page,
            $http_query = "?" . http_build_query($_GET);
        } else {
            $http_query = "?";
        }
        //Show pagination links
        if ($total_pages > 1) {
            echo '<ul class="pagination text-center">';
            for ($i = 1; $i <= $total_pages; $i++) {
                ($page == $i) ? $li_class = ' active' : $li_class = "";
                echo '<li class="page-item' . $li_class . '""><a class="page-link" href="reviews.php' . $http_query . '&page=' . $i . '">' . $i . '</a></li>';
            }
            echo '</ul></div>';
        }
        ?>
    </div>
    <!--    Pagination links end-->
</div>
</div>
</div>
</div>
<!--Main container end-->
<script>
    function get_checkboxes() { for (var e = document.getElementsByName("rid[]"), t = [], n = e.length - 1; n >= 0; n--) (e[n].type = "checkbox") && t.push(e[n]); return t }
    function change_checkboxes(e, t) { for (var n = e.length - 1; n >= 0; n--) e[n].checked = "boolean" == typeof t ? t : !e[n].checked }

    function select_all() { change_checkboxes(get_checkboxes(), !0) }
    function unselect_all() { change_checkboxes(get_checkboxes(), !1) }
    function checkbox_value() { 
        var _e = get_checkboxes();
        var formData = [];
        if(_e.length > 0) {
            _e.forEach(function(input){
                if(input.checked) {
                    formData.push({name:input.name,value:input.value});
                }
            });
        }
        return formData;
    }

    $("#selectAll").on("change", function(){
        if($(this).is(":checked")) {
            select_all();
        } else {
            unselect_all();
        }
    });

    //Delete Logs
    $('#js-delete-reports').on('click', function (e) {
        e.preventDefault();
        var data = checkbox_value();
        if(data && data.length) {
            if (window.confirm("<?php echo I18N("Are you sure you want to delete this"); ?>")) {
                $.ajax({
                    url: "review-delete.php",
                    data: data,
                    type: 'POST',
                    success: function (res) {
                        alert(res.message);
                        window.location.reload();
                    }
                });
            }
        }
    });
</script>

<?php include_once './includes/footer.php'; ?>

