<?php
session_start();
require_once '../includes/auth_validate.php';
require_once '../config/config.php';
if (isset($_POST['action'])) {
	include_once "uploader.php";

	$action_name = $_POST['action'];
	$uploader = new Uploader($_FILES['files']);
	$uploader->set_upload_to("../../uploads/assets");
	$uploader->set_valid_extensions(array('jpg', 'JPG', 'jpeg', 'png', 'PNG'));
	
	if ($uploader->is_valid_extension() === false) {
		$_SESSION['error'] = "Uploaded Error!";
	        	header('location: ../settings.php');
	        	exit;
	}else{
		
		if ($uploader->run() === false) {
			$_SESSION['error'] = "Uploaded Error!";
        	header('location: ../settings.php');
        	exit;
		}else{
			$db = getDbInstance();
			$filename = $_FILES['files']['name'];
		    $data = Array ('value' => htmlentities($filename[0]));
		    $db->where('name', $action_name);
		    $updated = $db->update('meta', $data);

		    if($updated)
		    {
				$_SESSION['success'] = I18N("Uploaded successfully");
	        	header('location: ../settings.php');
	        	exit;
		    } else {
		    	$_SESSION['error'] = "Uploaded Error!";
	        	header('location: ../settings.php');
	        	exit;
		    }
		}
		
	}
	
	exit;
}
?>