<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

include_once 'includes/header.php';
?>
<link href="assets/uppy/uppy.min.css" rel="stylesheet">
<style type="text/css">
  .uppy-DashboardItem-preview.file-exist .uppy-DashboardItem-progress {
    display: none;
  }
  .uppy-DashboardItem-preview.file-exist .uppy-DashboardItem-previewInnerWrap {
    background-color: darkorange !important;
  }
  }
</style>
<!--Main container start-->
<div id="page-wrapper">
    <div class="container-fuild">
        <div class="card mt-5">
    <div class="card-header">
        <strong><?php echo I18N("Upload Reports"); ?></strong>
        <a href="reviews.php" class="float-right">
        	<button class="btn btn-success btn-sm"><i class="far fa-address-book"></i> <?php echo I18N("View Reports"); ?></button>
        </a>
    </div>
    <div class="card-body">
        <?php include('./includes/flash_messages.php') ?>
    <!--    Begin filter section-->
    <div class="well">
       <div class="row">
           <div class="col-12">
            <div id="drag-drop-area"></div>
            <ul id="error-msg" style="margin: 10px 0;color: red"></ul>
           </div>
       </div>
    </div>
<!--   Filter section end-->

</div>
</div>
</div>
</div>
<!--Main container end-->
<script src="assets/uppy/uppy.min.js"></script>
<script src="assets/uppy/es_GL.min.js"></script>
    <script>
      var uppy = Uppy.Core({
          locale: Uppy.locales.es_GL,
          autoProceed: false,
          replaceTargetContent: true,
          restrictions: {
          allowedFileTypes: ['.pdf', '.PDF']
          }
        })
        .use(Uppy.Dashboard, {
          inline: true,
          target: '#drag-drop-area',
          showProgressDetails: true,
          note: '<?php echo I18N("PDF files only allowed to upload"); ?>',
          locale: {
            strings: {
              dropPaste : 'Soltar archivos o Abrir %{browse}',
              uploadComplete : 'Carga Finalizada',
              xFilesSelected: {
                '0': '%{smart_count} Archivo Seleccionados',
                '1': '%{smart_count} Archivos Seleccionados',
                '2': '%{smart_count} Archivos Seleccionados'
              }
            }
          }
        })
        .use(Uppy.XHRUpload, {
          endpoint: 'helpers/uploadApi.php',
          fieldName: 'file_name',
          method:'post'
        })

        uppy.on('upload-success', function (file, response) {
               if(response.body && response.body.isExist) {
                  setTimeout(addErrorClass(file.name), 0);
                  $("#error-msg").append("<li>"+response.body.fileName + " <?php echo I18N("is already exit in system"); ?> </li>");
                  uppy.info(response.body.fileName + " <?php echo I18N("is already exit in system"); ?>", 'error', 1000);
               }
        });

        function addErrorClass(fileid) {
          $(`li.uppy-DashboardItem[title='${fileid}'] .uppy-DashboardItem-preview`).addClass('file-exist');
        }
    </script>

<?php include_once './includes/footer.php'; ?>

