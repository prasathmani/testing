<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';


include_once 'includes/header.php';
?>
<link rel="stylesheet" type="text/css" href="assets/datatables/datatables.min.css" />
<!--Main container start-->
<div id="page-wrapper">
    <div class="container">
        <div class="card mt-5">
    <div class="card-header">
            <strong><?php echo I18N("Users"); ?></strong>
            <span class="float-right">
                <button class="btn btn-danger btn-sm" id="js-delete-users"><i class="fas fa-trash"></i> <?php echo I18N("Delete"); ?></button>
            </span>
            <a href="user-add.php?operation=create" class="float-right mr-2">
            	<button class="btn btn-success btn-sm"><i class="far fa-address-book"></i> <?php echo I18N("New user"); ?></button>
            </a>
    </div>
    <div class="card-body">
        <?php include('./includes/flash_messages.php') ?>
 

        <table class="table table-striped table-bordered table-condensed" id="js-users">
            <thead>
                <tr>
                    <th class="header">#</th>
                    <th> <input class="form-check-input position-static ml-0" type="checkbox" id="selectAll" value="option1" aria-label="Select All"> </th>
                    <th><?php echo I18N("Request number"); ?></th>
                    <th><?php echo I18N("Year"); ?></th>
                    <th><?php echo I18N("Password"); ?></th>
                    <th><?php echo I18N("Created"); ?></th>
                    <th><?php echo I18N("Actions"); ?></th>
                </tr>
            </thead>
            <tbody>     
            </tbody>
        </table>
</div>
</div>
</div>
</div>
<!--Main container end-->
<script type="text/javascript" src="assets/datatables/datatables.min.js"></script>
<script>
    function get_checkboxes() { for (var e = document.getElementsByName("uid[]"), t = [], n = e.length - 1; n >= 0; n--) (e[n].type = "checkbox") && t.push(e[n]); return t }
    function change_checkboxes(e, t) { for (var n = e.length - 1; n >= 0; n--) e[n].checked = "boolean" == typeof t ? t : !e[n].checked }

    function select_all() { change_checkboxes(get_checkboxes(), !0) }
    function unselect_all() { change_checkboxes(get_checkboxes(), !1) }
    function checkbox_value() { 
        var _e = get_checkboxes();
        var formData = [];
        if(_e.length > 0) {
            _e.forEach(function(input){
                if(input.checked) {
                    formData.push({name:input.name,value:input.value});
                }
            });
        }
        return formData;
    }

    $("#selectAll").on("change", function(){
        if($(this).is(":checked")) {
            select_all();
        } else {
            unselect_all();
        }
    });

    //Delete users
    $('#js-delete-users').on('click', function (e) {
        e.preventDefault();
        var data = checkbox_value();
        if(data && data.length) {
            if (window.confirm("<?php echo I18N("Are you sure you want to delete this"); ?>")) {
                $.ajax({
                    url: "user-delete.php",
                    data: data,
                    type: 'POST',
                    success: function (res) {
                        alert(res.message);
                        window.location.reload();
                    }
                });
            }
        }
    });

    //datatable
    $(document).ready(function() {
       $('#js-users').DataTable( {
            language: {
                url: 'helpers/datatable-spanish.json'
            },
            "processing": true,
            "serverSide": true,
            "ajax": "helpers/userDataTable.php",
            "order": [[ 0, "desc" ]],
            "columnDefs": [
                { 
                    "targets": [1, 4, 6], //first column / numbering column
                    "orderable": false, //set not orderable
                },
                { "width": "10%", "targets": 6 },
            ],
             "fnRowCallback" : function(nRow, aData, iDisplayIndex){      
                var oSettings = this.fnSettings();
                $("td:first", nRow).html(oSettings._iDisplayStart+iDisplayIndex +1);
                return nRow;
            },
        });
    });
</script>

<?php include_once './includes/footer.php'; ?>

