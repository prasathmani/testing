<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';


include_once 'includes/header.php';
?>
<link href="https://transloadit.edgly.net/releases/uppy/v1.2.0/uppy.min.css" rel="stylesheet">
<!--Main container start-->
<div id="page-wrapper">
    <div class="container-fuild">
        <div class="card mt-5">
    <div class="card-header">
        <strong>Upload Reports</strong>
        <a href="reviews.php" class="float-right">
        	<button class="btn btn-success btn-sm"><i class="far fa-address-book"></i> View Reviews</button>
        </a>
    </div>
    <div class="card-body">
        <?php include('./includes/flash_messages.php') ?>
    <!--    Begin filter section-->
    <div class="well">
       <div class="row">
           <div class="col-12">
            <div id="drag-drop-area"></div>
           </div>
       </div>
    </div>
<!--   Filter section end-->



</div>
</div>
</div>
</div>
<!--Main container end-->
<script src="https://transloadit.edgly.net/releases/uppy/v1.2.0/uppy.min.js"></script>
    <script>
      var uppy = Uppy.Core()
        .use(Uppy.Dashboard, {
          inline: true,
          target: '#drag-drop-area',
          replaceTargetContent: true
        })
        .use(Uppy.XHRUpload, {
          endpoint: 'helpers/uploadApi.php',
          fieldName: 'file_name',
          method:'post'
        })

        uppy.on('upload-success', function (fileId, data) {
               console.log("Uploaded!", data);
        });

      uppy.on('complete', (result) => {
        console.log('Upload complete! We’ve uploaded these files:', result.successful)
      })
    </script>

<?php include_once './includes/footer.php'; ?>

