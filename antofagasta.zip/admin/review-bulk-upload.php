<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

include_once 'includes/header.php';
?>
<link href="https://transloadit.edgly.net/releases/uppy/v1.2.0/uppy.min.css" rel="stylesheet">
<style type="text/css">
  .uppy-DashboardItem-preview.file-exist .uppy-DashboardItem-progress {
    display: none;
  }
  .uppy-DashboardItem-preview.file-exist .uppy-DashboardItem-previewInnerWrap {
    background-color: darkorange !important;
  }
  }
</style>
<!--Main container start-->
<div id="page-wrapper">
    <div class="container-fuild">
        <div class="card mt-5">
    <div class="card-header">
        <strong>Upload Reports</strong>
        <a href="reviews.php" class="float-right">
        	<button class="btn btn-success btn-sm"><i class="far fa-address-book"></i> View Reviews</button>
        </a>
    </div>
    <div class="card-body">
        <?php include('./includes/flash_messages.php') ?>
    <!--    Begin filter section-->
    <div class="well">
       <div class="row">
           <div class="col-12">
            <div id="drag-drop-area"></div>
            <ul id="error-msg" style="margin: 10px 0;color: red"></ul>
           </div>
       </div>
    </div>
<!--   Filter section end-->

</div>
</div>
</div>
</div>
<!--Main container end-->
<script src="https://transloadit.edgly.net/releases/uppy/v1.2.0/uppy.min.js"></script>
    <script>
      var uppy = Uppy.Core({
          autoProceed: false,
          replaceTargetContent: true,
          restrictions: {
          allowedFileTypes: ['.pdf', '.PDF']
          }
        })
        .use(Uppy.Dashboard, {
          inline: true,
          target: '#drag-drop-area',
          showProgressDetails: true,
          note: 'PDF files only allowed to upload',
        })
        .use(Uppy.XHRUpload, {
          endpoint: 'helpers/uploadApi.php',
          fieldName: 'file_name',
          method:'post'
        })

       //  uppy.on('upload-success', (file, response) => { 
       //   const currentProgress = uppy.getFile(file.id).progress;
       //   if(response.body && response.body.isExist) {
       //   uppy.setFileState(file.id, {
       //     progress: Object.assign({}, currentProgress, { 
       //       uploadComplete: false, 
       //       percentage: 100, 
       //       bytesUploaded: currentProgress.bytesTotal 
       //     }),
       //     response: response, 
       //     uploadURL: response.uploadURL, 
       //     isPaused: false 
       //   })
       // }
        
       //   uppy._calculateTotalProgress();
       // });

        uppy.on('upload-success', function (file, response) {
               console.log("Uploaded!", response);
               if(response.body && response.body.isExist) {
                  // $(`li.uppy-DashboardItem[title='${file.name}'`).addClass('file-exist');
                  setTimeout(addErrorClass(file.name), 0);
                  $("#error-msg").append("<li>"+response.body.fileName + " is already exit in system </li>");
                  uppy.info(response.body.fileName + " is already exit in system", 'error', 1000);
               }
        });

        function addErrorClass(fileid) {
          $(`li.uppy-DashboardItem[title='${fileid}'] .uppy-DashboardItem-preview`).addClass('file-exist');
        }
    </script>

<?php include_once './includes/footer.php'; ?>

