<?php

//Note: This file should be included first in every php page.
error_reporting(E_ALL);
ini_set('display_errors', 'On');
define('BASE_PATH', dirname(dirname(__FILE__)));
define('APP_FOLDER', 'antofagasta');
define('CURRENT_PAGE', basename($_SERVER['REQUEST_URI']));
// Set the timezone 
date_default_timezone_set('America/Santiago');

require_once BASE_PATH . '/lib/MysqliDb/MysqliDb.php';
require_once BASE_PATH . '/helpers/helpers.php';
global $lang;

/*
|--------------------------------------------------------------------------
| DATABASE CONFIGURATION
|--------------------------------------------------------------------------
 */

define('DB_HOST', "localhost");
define('DB_USER', "dbadmin");
define('DB_PASSWORD', "Root@123$");
define('DB_NAME', "antofagasta");

/**
 * Get instance of DB object
 */
function getDbInstance() {
	return new MysqliDb(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
}

/**
 * Set Default timezone
 */
$db = getDbInstance();
$db->where ("name", "time_zone");
$timezone = $db->get ("meta", null, ["value"]);
if($timezone[0]["value"]) {
    date_default_timezone_set($timezone[0]["value"]);
} else {
    date_default_timezone_set('America/Santiago');
}

/*
 * get language translations from json file
 * @param int $tr
 * @return array
 */
function fm_get_translations() {
    try {
        $content = @file_get_contents("./config/translation.json");
        if($content !== FALSE) {
            $lng = json_decode($content, TRUE);
            global $lang_list;
            foreach ($lng as $key => $value)
            {
                $lang_list[$key] = $value;
            }
            return $lang_list;
        }

    }
    catch (Exception $e) {
        echo $e;
    }
}

/**
 * Encode html entities
 * @param string $text
 * @return string
 */
function fm_enc($text)
{
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

/**
 * Language Translation System
 * @param string $txt
 * @return string
 */
function I18N($txt) {
    global $lang;

    $i18n = fm_get_translations();

    if (isset($i18n[$txt])) { 
    	return fm_enc($i18n[$txt]); 
    } else {
    	return "$txt";
    }
}
