<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

$db = getDbInstance();
$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$meta = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $meta[$data['name']] = $data['value'];
    }
}

require_once 'includes/header.php';
?>
<link rel="stylesheet" href="assets/trumbowyg/ui/trumbowyg.min.css">
<link rel="stylesheet" href="assets/trumbowyg/plugins/colors/ui/trumbowyg.colors.css">
<div id="page-wrapper">
    <div class="col-12">

        <div class="card mt-5">
            <div class="card-header">
                <span class="card-title"><?php echo I18N("Login Page - Header"); ?></span>
                <span class="float-right form-inlinet">
                    <button class="btn btn-success btn-sm" id="save_login_left_clm_1"><?php echo I18N("Save"); ?></button>
                </span>
            </div>
            <div class="card-body">
                <fieldset>
                    <div class="form-group">
                        <textarea name="login_left_clm_1" id="login_left_clm_1">
                            <?php echo $meta['login_left_clm_1']; ?>
                        </textarea>
                    </div>
                </fieldset>
            </div>
        </div>


        <div class="card mt-3">
            <div class="card-header">
                <span class="card-title"><?php echo I18N("Review Page - Header"); ?></span>
                <span class="float-right form-inlinet">
                    <button class="btn btn-success btn-sm" id="save_review_head_clm"><?php echo I18N("Save"); ?></button>
                </span>
            </div>
            <div class="card-body">
                <fieldset>
                    <div class="form-group">
                        <textarea name="review_head_clm" id="review_head_clm">
                            <?php echo $meta['review_head_clm']; ?>
                        </textarea>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <span class="card-title"><?php echo I18N("Review Page - Body"); ?></span>
                <span class="float-right form-inlinet">
                    <button class="btn btn-success btn-sm" id="save_review_body_clm"><?php echo I18N("Save"); ?></button>
                </span>
            </div>
            <div class="card-body">
                <fieldset>
                    <div class="form-group">
                        <textarea name="review_head_clm" id="review_body_clm">
                            <?php echo $meta['review_body_clm']; ?>
                        </textarea>
                    </div>
                </fieldset>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <span class="card-title"> <?php echo I18N("Reports"); ?><?php echo I18N("Footer"); ?></span>
                <span class="float-right form-inlinet">
                    <button class="btn btn-success btn-sm" id="save_login_footer"><?php echo I18N("Save"); ?></button>
                </span>
            </div>
            <div class="card-body">
                <fieldset>
                    <div class="form-group">
                        <textarea name="login_footer" id="login_footer">
                            <?php echo $meta['login_footer']; ?>
                        </textarea>
                    </div>
                </fieldset>
            </div>
        </div>

    </div>
</div>
<script src="assets/trumbowyg/trumbowyg.min.js"></script>
<script src="assets/trumbowyg/plugins/colors/trumbowyg.colors.min.js"></script>
<!-- Import Trumbowyg plugins... -->
<script>
   $('#login_left_clm_1, #login_footer, #review_head_clm, #review_body_clm').trumbowyg({
        btns: [
                ['viewHTML'],
                ['undo', 'redo'], // Only supported in Blink browsers
                ['formatting'],
                ['strong', 'em', 'del'],
                ['superscript', 'subscript'],
                ['link'],
                ['insertImage'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                ['unorderedList', 'orderedList'],
                ['horizontalRule'],
                ['removeformat'],
                ['fullscreen'],
                ['foreColor', 'backColor'],
        ],
        semantic: {
            'div': 'div' // Editor does nothing on div tags now
        }
    });

    function saveMetaData(data) {
        $.ajax({
            type: "POST",
            data: data,
            url: 'helpers/saveMeta.php',
            dataType:"json",
            success: function(response){
                if(response.success) {
                    alert('Saved Successfuly')
                } else {
                    alert("ERROR! Try Again")
                }
            }
          });
    }
    //save
    $("#save_login_left_clm_1").on("click", function(e){
        e.preventDefault();
        let _val = $("#login_left_clm_1").val();
        data = {'name': 'login_left_clm_1', 'value': JSON.stringify(_val)};
        saveMetaData(data);
    });

    $("#save_review_head_clm").on("click", function(e){
        e.preventDefault();
        let _val = $("#review_head_clm").val();
        data = {'name': 'review_head_clm', 'value': JSON.stringify(_val)};
        saveMetaData(data);
    });

    $("#save_review_body_clm").on("click", function(e){
        e.preventDefault();
        let _val = $("#review_body_clm").val();
        data = {'name': 'review_body_clm', 'value': JSON.stringify(_val)};
        saveMetaData(data);
    });

    $("#save_login_footer").on("click", function(e){
        e.preventDefault();
        let _val = $("#login_footer").val();
        data = {'name': 'login_footer', 'value': JSON.stringify(_val)};
        saveMetaData(data);
    });
</script>
<?php include_once 'includes/footer.php'; ?>
