<?php
//meta data
$db = getDbInstance();
$cols = Array ("name", "value");
$db->where('name', 'site_admin_footer');
$meta = $db->get ("meta", null, $cols);
?>
</div>
    <!-- /#wrapper -->

    <?php echo html_entity_decode($meta[0]['value']); ?>

    <!-- Bootstrap Core JavaScript -->

        <script src="assets/js/bootstrap.min.js"></script>


</body>

</html>
