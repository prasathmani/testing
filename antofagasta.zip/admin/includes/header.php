<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Laboratorio Luis Pasteur Antofagasta">
        <meta name="author" content="CCP Programmers">

        <title>Laboratorio Luis Pasteur Antofagasta</title>

        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- Bootstrap Core CSS -->
        <link  rel="stylesheet" href="assets/css/bootstrap.min.css"/>

        <!-- Custom CSS -->
        <link href="assets/css/php-admin.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">

        <script src="assets/js/jquery.min.js" type="text/javascript"></script>

    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] == true): ?>
                <nav class="navbar navbar-expand-sm navbar-dark bg-dark shadow" role="navigation">
                    <a class="navbar-brand" href="index.php"><img src="assets/images/logo-sm.png" alt="Antofagasta"> <strong>Antofagasta</strong></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-mainmenu" aria-controls="nav-mainmenu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <!-- /.navbar-header -->
                    <div class="collapse navbar-collapse" id="nav-mainmenu">

                        <ul class="navbar-nav ml-auto">
                            <!-- /.dropdown -->
                            <li class="nav-item">
                                <a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                            </li>

                            <li class="nav-item">
                                <a href="user.php" class="nav-link"><i class="fa fa-users fa-fw"></i> Users</a>
                            </li>

                            <li class="nav-item">
                                <a href="reviews.php" class="nav-link"><i class="fas fa-file-upload"></i> Reviews</a>
                            </li>

                            <li class="nav-item">
                                <a href="config-page.php" class="nav-link"><i class="fas fa-file-contract"></i> User Screens</a>
                            </li>
                            
                            <!-- /.dropdown -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="nav-user" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-user-circle fa-fw"></i> Administrator
                                </a>
                                <div class="dropdown-menu dropdown-user" aria-labelledby="nav-user">
                                    <a class="dropdown-item" href="settings.php">Settings</a>
                                    <a class="dropdown-item" href="logout.php">Logout</a>
                                </div>
                                <!-- /.dropdown-user -->
                            </li>
                            <!-- /.dropdown -->
                        </ul>
                    </div>
                    <!-- /.navbar-top-links -->

                </nav>
            <?php endif;?>
            <!-- The End of the Header -->
