<?php
//meta data
$db = getDbInstance();
$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$META = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $META[$data['name']] = $data['value'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="<?php echo $META['site_description']; ?>">
        <meta name="keywords" content="<?php echo $META['site_keywords']; ?>">
        <meta name="author" content="<?php echo $META['site_author']; ?>">

        <title><?php echo $META['site_title']; ?></title>

        <link rel="shortcut icon" type="image/png" href="<?php echo '../uploads/assets/'.$META['site_favicon']; ?>" />

        <!-- Bootstrap Core CSS -->
        <link  rel="stylesheet" href="assets/css/bootstrap.min.css"/>

        <!-- Custom CSS -->
        <link href="assets/css/php-admin.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">

        <script src="assets/js/jquery.min.js" type="text/javascript"></script>

    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] == true): ?>
                <nav class="navbar navbar-expand-sm navbar-dark bg-dark shadow" role="navigation">
                    <a class="navbar-brand" href="index.php">
                        <img src="<?php echo '../uploads/assets/'.$META['site_admin_logo']; ?>" alt="<?php echo $META['site_admin_title']; ?>"> 
                        <strong><?php echo $META['site_admin_title']; ?></strong>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-mainmenu" aria-controls="nav-mainmenu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <!-- /.navbar-header -->
                    <div class="collapse navbar-collapse" id="nav-mainmenu">

                        <ul class="navbar-nav ml-auto">
                            <!-- /.dropdown -->
                            <li class="nav-item">
                                <a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt"></i> <?php echo I18N("Dashboard"); ?></a>
                            </li>

                            <li class="nav-item">
                                <a href="user.php" class="nav-link"><i class="fa fa-users fa-fw"></i> <?php echo I18N("Users"); ?></a>
                            </li>

                            <li class="nav-item">
                                <a href="reviews.php" class="nav-link"><i class="fas fa-file-upload"></i> <?php echo I18N("Reports"); ?></a>
                            </li>

                            <li class="nav-item">
                                <a href="config-page.php" class="nav-link"><i class="fas fa-file-contract"></i> <?php echo I18N("User Screens"); ?></a>
                            </li>
                            
                            <!-- /.dropdown -->
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="nav-user" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-user-circle fa-fw"></i> <?php echo I18N("Administrator"); ?>
                                </a>
                                <div class="dropdown-menu dropdown-user" aria-labelledby="nav-user">
                                    <a class="dropdown-item" href="settings.php"><?php echo I18N("Settings"); ?></a>
                                    <a class="dropdown-item" href="translation.php"><?php echo I18N("Translation"); ?></a>
                                    <a class="dropdown-item" href="logout.php"><?php echo I18N("Logout"); ?></a>
                                </div>
                                <!-- /.dropdown-user -->
                            </li>
                            <!-- /.dropdown -->
                        </ul>
                    </div>
                    <!-- /.navbar-top-links -->

                </nav>
            <?php endif;?>
            <!-- The End of the Header -->
