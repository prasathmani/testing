
<fieldset>
<?php
$rut = [];
$cols = Array ("id", "request_number", "year");
$db = getDbInstance();
$users = $db->get ("users", null, $cols);
if ($db->count > 0)
    foreach ($users as $user) { 
        array_push($rut, $user);
    }
?>
    <div class="form-group">
        <label>Request Number *</label>
        <select name="user_rid" class="form-control selectpicker" required>
            <option value="" data-rid="" >-- Select Request Number --</option>
            <?php
            foreach ($rut as $opt) {
                if ($edit && $opt['request_number'] == $review['user_rid']) {
                    $sel = "selected";
                } else {
                    $sel = "";
                }
                echo '<option data-rid="'.$opt['id'].'" value="'.$opt['request_number'].'"' . $sel . '>' . $opt['request_number'] . '</option>';
            }

            ?>
        </select>
        <input type="hidden" id="js-user_id" name="user_id" value="<?php echo $review['user_id']; ?>">
    </div> 

    
    <?php if(!$edit) { ?>
    <div class="form-group">
        <label for="file_name">File Upload *</label>
        <input type="file" name="file_name" class="form-control" required="required" id="file_name">
    </div>
    <?php } ?>
    

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-primary" >Submit <span class="glyphicon glyphicon-send"></span></button>
    </div>        
</fieldset>