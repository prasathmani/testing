<fieldset>
    <div class="form-group">
        <label for="request_number"><?php echo I18N("Request number"); ?> *</label>
          <input type="text" name="request_number" value="<?php echo $edit ? $customer['request_number'] : ''; ?>" placeholder="<?php echo I18N("Request number"); ?>" class="form-control" required="required" id="request_number" >
    </div> 

    <div class="form-group">
        <label for="year"><?php echo I18N("Year"); ?> *</label>
        <input type="number" min="<?php echo date("Y") ?>" max="2030" step="1" value="<?php echo $edit ? $customer['year'] : date("Y"); ?>" name="year" value="" placeholder="<?php echo I18N("Year"); ?>" class="form-control" required="required" id="year" pattern= "[0-9]">
    </div> 

    <div class="form-group">
        <label for="password"><?php echo I18N("Password"); ?> *</label>
        <input type="text" name="password" value="<?php echo $edit ? $customer['password'] : ''; ?>" placeholder="<?php echo I18N("Password"); ?>" class="form-control" required id="password">
    </div> 
    

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-primary" ><?php echo I18N("Submit"); ?> <span class="glyphicon glyphicon-send"></span></button>
    </div>        
</fieldset>