<?php
session_start();
require_once './config/config.php';
require_once './includes/auth_validate.php';


//serve POST method, After successful insert, redirect to customers.php page.
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    //Mass Insert Data. Keep "name" attribute in html form same as column name in mysql table.
    $data_to_store = array_filter($_POST);

    //Insert timestamp
    
    $data_to_store['password'] = $_POST['password'];
    $data_to_store['status'] = 1;
    $data_to_store['created_at'] = date('Y-m-d H:i:s');
    $db = getDbInstance();
    
    $last_id = $db->insert('users', $data_to_store);

    if($last_id)
    {
    	$_SESSION['success'] = "User added successfully!";
    	header('location: user.php');
    	exit();
    }
    else
    {
        echo 'insert failed: ' . $db->getLastError();
        exit();
    }
}

//We are using same form for adding and editing. This is a create form so declare $edit = false.
$edit = false;

require_once 'includes/header.php'; 
?>
<div id="page-wrapper">
    <div class="container">
        <div class="card mt-5">
            <div class="card-header">
                Add User
            </div>
            <div class="card-body">
                <?php
                include_once('includes/flash_messages.php');
                ?>
                <form class="well form-horizontal" action=" " method="post"  id="user_form" enctype="multipart/form-data">
                    <?php include_once './forms/user_form.php'; ?>
                </form>
            </div>
        </div>
    </div>
</div>


<?php include_once 'includes/footer.php'; ?>