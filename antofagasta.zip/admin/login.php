<?php
session_start();

require_once './config/config.php';
$token = bin2hex(openssl_random_pseudo_bytes(16));

//If User has already logged in, redirect to dashboard page.
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === TRUE) {
	header('Location:index.php');
}

//If user has previously selected "remember me option" :
if (isset($_COOKIE['series_id']) && isset($_COOKIE['remember_token'])) {

	//Get user credentials from cookies.
	$series_id = filter_var($_COOKIE['series_id']);
	$remember_token = filter_var($_COOKIE['remember_token']);
	$db = getDbInstance();
	//Get user By serirs ID :
	$db->where("series_id", $series_id);
	$row = $db->get('admin_accounts');


	if ($db->count >= 1) {

		//User found. verify remember token
		if (password_verify($remember_token, $row[0]['remember_token'])) {
			//Verify if expiry time is modified.

			$expires = strtotime($row[0]['expires']);

			if(strtotime(date()) > $expires){

				//Remember Cookie has expired.
				clearAuthCookie();
				header('Location:login.php');
				exit;
			}

			$_SESSION['user_logged_in'] = TRUE;
			$_SESSION['admin_type'] = $row[0]['admin_type'];
			header('Location:index.php');
			exit;
		} else {
			clearAuthCookie();
			header('Location:login.php');
			exit;
		}
	} else {
		clearAuthCookie();
		header('Location:login.php');
		exit;
	}
}

include_once 'includes/header.php';
?>
<div class="login-page">
	<div class="container login-page">
	    <div class="card card-container col-6">
	        <div class="text-center">
	            <img src="assets/images/logo.png" alt="antofagasta">
	        </div>
	        <p id="profile-name" class="profile-name-card"></p>
	        <form class="form-signin loginform" method="POST" action="authenticate.php">
	            <span id="reauth-email" class="reauth-email"></span>
	            <input type="text" id="username" name="username" class="form-control" placeholder="Nombre de usuario" required autofocus>
	            <input type="password" id="passwd" name="passwd" class="form-control" placeholder="Contraseña" required>
	            <div id="remember" class="checkbox">
	                <label>
	                    <input type="checkbox" name="remember" value="remember-me"> Recordar
	                </label>
	            </div>
	            <?php
	            if (isset($_SESSION['login_failure'])) {?>
	                <div class="alert alert-danger alert-dismissable">
	                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
	                    <?php echo $_SESSION['login_failure'];unset($_SESSION['login_failure']); ?>
	                </div>
	            <?php }?>

	            <button class="btn btn-lg btn-primary btn-block btn-signin loginField" type="submit">Iniciar sesión</button>
	        </form><!-- /form -->
	    </div><!-- /card-container -->
	</div><!-- /container -->
</div>

<?php include_once 'includes/footer.php';?>
