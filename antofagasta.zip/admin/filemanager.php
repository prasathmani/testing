<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

include_once('includes/header.php');
?>
<section id="page-wrapper">
    <div class="container-fluid mt-1">
            <!-- <iframe src="tinyfilemanager.php" width="100%" height="500px" border="0"></iframe> -->

            <?php
          define('FM_EMBED', true);
          define('FM_SELF_URL', $_SERVER['PHP_SELF']);
          require 'tinyfilemanager.php';
          ?>
    </div>
</section>
<!-- /#page-wrapper -->

<?php include_once('includes/footer.php'); ?>
