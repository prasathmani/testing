<?php 
session_start();
require_once 'includes/auth_validate.php';
require_once './config/config.php';
$del_id = $_POST['rid'];


//server response header
function jsonResponse($data) {
    if($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}

/**
 * Delete  file or folder (recursively)
 * @param string $path
 * @return bool
 */
function fm_rdelete($path)
{
    if (is_link($path)) {
        return unlink($path);
    } elseif (is_dir($path)) {
        $objects = scandir($path);
        $ok = true;
        if (is_array($objects)) {
            foreach ($objects as $file) {
                if ($file != '.' && $file != '..') {
                    if (!fm_rdelete($path . '/' . $file)) {
                        $ok = false;
                    }
                }
            }
        }
        return ($ok) ? rmdir($path) : false;
    } elseif (is_file($path)) {
        return unlink($path);
    }
    return false;
}

function getFileUrl($file_name) {
    $file_1 = str_replace('../', '', $file_name);
    return '../'.$file_1;
}

// Delete file / folder
function deleteReport($del) {
    
    if ($del) {
        if ($del != '' && $del != '..' && $del != '.') {
            // $path = "../uploads";
            $del = getFileUrl($del);
            // $is_dir = is_dir($path . '/' . $del);
            if (fm_rdelete($del)) {
                return true;
            } else {
                jsonResponse(array("status" => false, "message" => I18N("Unable to delete Reports")));
            }
        } else {
            jsonResponse(array("status" => false, "message" => I18N("Unable to delete Reports")));
        }
    }
}


if ($del_id && $_SERVER['REQUEST_METHOD'] == 'POST') 
{

	if($_SESSION['admin_type']!='admin'){
    	jsonResponse(array("status" => false, "message" => I18N("You don't have permission to perform this action")));
	}

    $reports = $del_id;
    $db = getDbInstance();
    $uploadSuccess = false;

    if($reports) {
        foreach ($reports as $report) {
            $db->where('id', $report);
            $review = $db->getOne("reviews");
            $file_name = $review['file_name'];

            $db->where('id', $report);
            $status = $db->delete('reviews');
            if ($status) {
                $uploadSuccess = deleteReport($file_name);
            } else {
                jsonResponse(array("status" => false, "message" => I18N("Unable to delete Reports")));
            }
        }

        if($uploadSuccess) {
            jsonResponse(array("status" => true, "message" => I18N("Deleted successfully")));
        } 
    }  
}