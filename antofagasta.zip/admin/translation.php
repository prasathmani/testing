<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{

    $file_path = './config/translation.json';

    if (isset($_POST['savedata'])) {
        $writedata = $_POST['savedata'];
        $fd = fopen($file_path, "w");
        @fwrite($fd, $writedata);
        fclose($fd);
        $_SESSION['success'] = I18N("Updated successfully");
    }

}

$content = @file_get_contents("./config/translation.json");

require_once 'includes/header.php';
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.1/ace.js"></script>
<style type="text/css" media="screen">
    #editor { 
        position: absolute;
        top: 55px;
        right: 0;
        bottom: 0;
        left: 0;
        min-height: 480px;
    }
</style>
<div id="page-wrapper">
    <div class="row">
        <div class="col-12 mt-2"><?php include('./includes/flash_messages.php') ?></div>
        <div class="col-12">
            <div class="card mt-5">
                <?php
                    include('./includes/flash_messages.php')
                ?>
                <div class="card-header">
                    <span class="card-title"><?php echo I18N("Translation"); ?></span>
                    <span class="float-right">
                    <button class="btn btn-success  btn-sm" id="js-save-translation"><i class="fas fa-save"></i> <?php echo I18N("Save"); ?></button>
                    </span>
                </div>
                <div class="card-body">
                    <textarea id="json_data" name="json_data" required="" autocomplete="off" class="form-control d-none" rows="20"><?php echo $content; ?></textarea>
                    <div id="editor"><?php echo $content; ?></div>
                </div>
            </div>
            
        </div>
</div>
<script>
    var editor = ace.edit("editor");
    editor.setTheme("ace/theme/monokai");
    editor.session.setMode("ace/mode/json");

    //Save file
    $("#js-save-translation").on("click", function(e) {
        e.preventDefault();
        var n = editor.getSession().getValue();
        if (n) {
            var a = document.createElement("form");
            a.setAttribute("method", "POST"), a.setAttribute("action", "");
            var o = document.createElement("textarea");
            o.setAttribute("type", "textarea"), o.setAttribute("name", "savedata");
            var c = document.createTextNode(n);
            o.appendChild(c), a.appendChild(o), document.body.appendChild(a), a.submit()
        }
    });
</script>
<?php include_once 'includes/footer.php'; ?>
