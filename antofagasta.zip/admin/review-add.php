<?php
session_start();
require_once './config/config.php';
require_once './includes/auth_validate.php';

$root_path = "../uploads";
$allowed_extensions = ''; 


defined('UPLOAD_PATH') || define('UPLOAD_PATH', $root_path);
defined('UPLOAD_EXTENSION') || define('UPLOAD_EXTENSION', $allowed_extensions);


//serve POST method, After successful insert, redirect to customers.php page.
if (!empty($_FILES)) 
{
    //Mass Insert Data. Keep "name" attribute in html form same as column name in mysql table.
    $data_to_store = array_filter($_POST);


    // Upload
    if (!empty($_FILES)) {
        $override_file_name = true;
        $f = $_FILES;
        $path = UPLOAD_PATH;
        $ds = DIRECTORY_SEPARATOR;

        $errors = 0;
        $uploads = 0;
        $allowed = (UPLOAD_EXTENSION) ? explode(',', UPLOAD_EXTENSION) : false;

        $filename = $_FILES['file_name']['name'];
        $tmp_name = $_FILES['file_name']['tmp_name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $isFileAllowed = ($allowed) ? in_array($ext, $allowed) : true;

        $fullPath = $path . $ds . $filename;

        list($test_type, $request_number, $password, $date, $time) = explode('_', $filename);
        list($day, $month, $year) = explode(' ', $date);

        if($request_number && $year) {
            $fullPath = $path .$ds. $year .$ds. $request_number .$ds. $filename;
        } else {
            die(sprintf('Error while uploading files. Uploaded files: %s', $uploads));
            exit();
        }
        //create new folders
        $folder = substr($fullPath, 0, strrpos($fullPath, "/"));

        if (!is_dir($folder)) {
            $old = umask(0);
            mkdir($folder, 0777, true);
            umask($old);
        }

        if (empty($f['file_name']['error']) && !empty($tmp_name) && $tmp_name != 'none' && $isFileAllowed) {
            if (move_uploaded_file($tmp_name, $fullPath)) {
                 //Insert timestamp
                $data_to_store['status'] = 1;
                $data_to_store['file_name'] = $fullPath;
                $data_to_store['file_date'] = $date;
                $data_to_store['created_on'] = date('Y-m-d H:i:s');
                $db = getDbInstance();
                $last_id = $db->insert('reviews', $data_to_store);

                if($last_id)
                {
                    $_SESSION['success'] = "Review added successfully!";
                    header('location: reviews.php');
                    exit();
                }
                else
                {
                    echo 'insert failed: ' . $db->getLastError();
                    exit();
                }

            } else {
                die(sprintf('Error while uploading files. Uploaded files: %s', $uploads));
                exit();
            }
        }
    }
}

//We are using same form for adding and editing. This is a create form so declare $edit = false.
$edit = false;

require_once 'includes/header.php'; 
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />
<div id="page-wrapper">
    <div class="container">
        <div class="card mt-5">
            <div class="card-header">
                <?php echo I18N("New Reports"); ?>
            </div>
            <div class="card-body">
                <?php
                include_once('includes/flash_messages.php');
                ?>
                <form class="well form-horizontal" action="" method="post" id="review_form" enctype="multipart/form-data">
                    <?php include_once './forms/review_form.php'; ?>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    $('.datepicker').datepicker();
    $('select[name="user_rid"]').change(function(){
        const _rrid = $(this).children('option:selected').data('rid');
        $("#js-user_id").val(_rrid);
    });
</script>

<?php include_once 'includes/footer.php'; ?>