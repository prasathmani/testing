<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';


$db = getDbInstance();
$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$meta = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $meta[$data['name']] = $data['value'];
    }
}

require_once 'includes/header.php';
?>
<div id="page-wrapper">
    <div class="row">
    <div class="col-6">
        <div class="card mt-5">
            <div class="card-header">
                <span class="card-title">Settings</span>
            </div>
            <div class="card-body">
                <form class="well form-horizontal" action="" method="post"  id="settings_form" enctype="multipart/form-data">
                    <fieldset>
                        <div class="form-group form-inline">
                            <label for="site_title" class="col-3">Site Title</label>
                              <input type="text" name="site_title" pattern="[a-zA-Z0-9\s]+" value="<?php echo $meta['site_title']; ?>" placeholder="Site Title" class="form-control col-7 ml-2" required="required" id="site_title">
                              <button type="button" class="btn btn-primary ml-2 save-meta-data"><i class="fas fa-save"></i></button>
                        </div>

                        <div class="form-group form-inline">
                            <label for="site_description" class="col-3">Site Description</label>
                            <input type="text" name="site_description" pattern="[a-zA-Z0-9\s]+" value="<?php echo $meta['site_description']; ?>" placeholder="Site Description" class="form-control col-7 ml-2" required="required" id="site_description">
                            <button type="button" class="btn btn-primary ml-2 save-meta-data"><i class="fas fa-save"></i></button>
                        </div>

                        <div class="form-group form-inline">
                            <label for="site_timezone" class="col-3">Time Zone</label>
                            <select class="form-control col-7 ml-2" name="time_zone">
                              <?php 
                                $tzlist = DateTimeZone::listIdentifiers(DateTimeZone::ALL);
                                foreach( $tzlist as $region )
                                {
                                    if ($region == $meta['time_zone']) {
                                        $sel = "selected";
                                    } else {
                                        $sel = "";
                                    }
                                    echo '<option value="'.$region.'" '.$sel.'>'.$region.'</option>';
                                }
                              ?>
                            </select>
                            <button type="button" class="btn btn-primary ml-2 save-meta-data"><i class="fas fa-save"></i></button>
                        </div> 

                        <div class="form-group form-inline">
                            <label for="upload_path" class="col-3">Upload Path</label>
                              <input type="text" name="upload_path" placeholder="Review upload folder path" class="form-control col-7 ml-2" required="required" id="upload_path" value="<?php echo $meta['upload_path']; ?>">
                              <button type="button" class="btn btn-primary ml-2 save-meta-data"><i class="fas fa-save"></i></button>
                        </div> 

                        <div class="form-group form-inline">
                            <label for="upload_max_size" class="col-3">Upload Max Size</label>
                              <input type="text" name="upload_max_size" placeholder="Review upload file maxmumim size" class="form-control col-7 ml-2" required="required" id="upload_max_size" value="<?php echo $meta['upload_max_size']; ?>">
                              <button type="button" class="btn btn-primary ml-2 save-meta-data"><i class="fas fa-save"></i></button>
                        </div> 
       
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
    <div class="col-6">
        <div class="card mt-5">
            <div class="card-header">
                <span class="card-title">Site Logo</span>
            </div>
            <div class="card-body">
                <form class="well form-horizontal" action="" method="post"  id="settings_form" enctype="multipart/form-data">
                    <fieldset>
                        <div class="form-group">
                              <input type="file" name="site_main_logo" class="form-control" required="required" id="site_main_logo">
                        </div>

                        <div class="form-group text-right">
                            <label></label>
                            <button type="submit" class="btn btn-primary">Submit <span class="glyphicon glyphicon-send"></span></button>
                        </div>        
                    </fieldset>
                </form>
            </div>
        </div>

        <div class="card mt-5">
            <div class="card-header">
                <span class="card-title">Site Favicon</span>
            </div>
            <div class="card-body">
                <form class="well form-horizontal" action="" method="post"  id="favico_form" enctype="multipart/form-data">
                    <fieldset>
                        <div class="form-group">
                              <input type="file" name="site_favicon" class="form-control" required="required" id="site_favicon">
                        </div>

                        <div class="form-group text-right">
                            <label></label>
                            <button type="submit" class="btn btn-primary">Submit <span class="glyphicon glyphicon-send"></span></button>
                        </div>        
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<script type="text/javascript">
    function saveMetaData(data) {
        $.ajax({
            type: "POST",
            data: data,
            url: 'helpers/saveMeta.php',
            dataType:"json",
            success: function(response){
                if(response.success) {
                    alert('Saved Successfuly')
                } else {
                    alert("ERROR! Try Again")
                }
            }
          });
    }
    //save
    $("button.save-meta-data").on("click", function(e){
        e.preventDefault();
        let _name = $(this).closest('.form-group').find('input, select').attr('name');
        let _value = $(this).closest('.form-group').find('input, select').val();
        data = {'name': _name, 'value': JSON.stringify(_value)};
        console.log(data);
        saveMetaData(data);
    });
</script>

<?php include_once 'includes/footer.php'; ?>
