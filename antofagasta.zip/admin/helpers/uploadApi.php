<?php
session_start();
require_once '../config/config.php';

$root_path = "../../uploads";
$allowed_extensions = 'PDF'; 

defined('UPLOAD_PATH') || define('UPLOAD_PATH', $root_path);
defined('UPLOAD_EXTENSION') || define('UPLOAD_EXTENSION', $allowed_extensions);

$db = getDbInstance();

    //server response header
    function responseHeader($type, $data) {
        if($type == "success") {
            header('Content-Type: application/json');
            echo json_encode($data);
        } else {
            header("HTTP/1.1 406 Not Acceptable");
            exit;
        }
    }

    function insertReviews($request_number, $fullPath, $date, $user_id) {
        global $db;
        $data_review['user_rid'] = $request_number;
        $data_review['file_name'] = $fullPath;
        $data_review['file_date'] = $date;
        $data_review['user_id'] = $user_id;
        $data_review['created_by'] = $_SESSION['admin_name'];
        $data_review['created_on'] = date('Y-m-d H:i:s');
        $data_review['status'] = 1;
        $last_id = $db->insert('reviews', $data_review);
        if($last_id) {
            return true;
        }
        else {
            return false;
        }
    }

    function insertData($filename, $fullPath) {
        global $db;
        list($test_type, $request_number, $password, $date, $time) = explode('_', $filename);
        list($day, $month, $year) = explode(' ', $date);
        $time = str_replace('.pdf', '', strtolower($time));
        $date = $date.':'.$time;

        $db->where("request_number", $request_number);
        $row = $db->get('users');
        if ($db->count >= 1) {
            $user_id = $row[0]['id'];
            if(insertReviews($request_number, $fullPath, $date, $user_id)) {
                return true;
            }
            else {
                return false;
            }
        } else {
            //Insert user
            $data_user['request_number'] = $request_number;
            $data_user['year'] = $year;
            $data_user['password'] = $password;
            $data_user['status'] = 1;
            $data_user['created_at'] = date('Y-m-d H:i:s');
            
            $user_id = $db->insert('users', $data_user);
            if(insertReviews($request_number, $fullPath, $date, $user_id)) {
                return true;
            }
            else {
                return false;
            }
        }
    }


    // Upload
    if (!empty($_FILES)) {
        $override_file_name = true;
        $f = $_FILES;
        $path = UPLOAD_PATH;
        $ds = DIRECTORY_SEPARATOR;

        $errors = 0;
        $uploads = 0;
        $allowed = (UPLOAD_EXTENSION) ? explode(',', UPLOAD_EXTENSION) : false;

        $filename = $_FILES['file_name']['name'];
        $tmp_name = $_FILES['file_name']['tmp_name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $isFileAllowed = ($allowed) ? in_array($ext, $allowed) : true;
        $fullPath = $path . $ds . $filename;

        list($test_type, $request_number, $password, $date, $time) = explode('_', $filename);
        list($day, $month, $year) = explode(' ', $date);

        if($request_number && $year) {
            $fullPath = $path .$ds. $year .$ds. $request_number .$ds. $filename;
        } else {
            $data = array("successful" => false);
            responseHeader("error", $data);
        }

        //create new folders
        $folder = substr($fullPath, 0, strrpos($fullPath, "/"));

        if (!is_dir($folder)) {
            $old = umask(0);
            mkdir($folder, 0777, true);
            umask($old);
        }

        if (empty($f['file_name']['error']) && !empty($tmp_name) && $tmp_name != 'none' && $isFileAllowed) {
            if (!file_exists($fullPath)) {   
                if (move_uploaded_file($tmp_name, $fullPath)) {
                    //call insert $fullPath
                    $insert = insertData($filename, $fullPath);
                    if($insert) {
                        $data = array("successful" => true, "uploadURL" => $fullPath);
                        responseHeader("success", $data);
                    }
                } else {
                    $data = array("successful" => false);
                    responseHeader("error", $data);
                }
            } else {
                $data = array("successful" => false, "isExist" => true, "fileName" => $filename);
                responseHeader("success", $data);
            }
        } else {
            $data = array("successful" => false);
            responseHeader("error", $data);
        }
    }

?>