<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';

//Handle update request. As the form's action attribute is set to the same script, but 'POST' method, 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	$input_field = $_REQUEST['name'];
    $input_values = json_decode($_REQUEST['value']);
    
    $db = getDbInstance();
    $data = Array ('value' => htmlentities($input_values));
    $db->where('name', $input_field);
    $updated = $db->update('meta', $data);

    if($updated)
    {
		die('{"jsonrpc" : "2.0", "success" : true}');
    } else {
    	die('{"jsonrpc" : "2.0", "success" : false}');	
    }
}

