<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';
$db = getDbInstance();

// DB table to use
$table = 'reviews';

// Table's primary key
$primaryKey = 'id';

function getFileUrl($file_name) {
    return str_replace('../', '', $file_name);
}

function table_actions($d) {
	return '<a href="'.htmlspecialchars(getFileUrl($d)).'" download>'.I18N("Download").'</a>';
}

function table_Selector($d) {
	return '<input class="form-check-input position-static ml-0" type="checkbox" name="rid[]" id="'.mt_rand(100000,999999).'" value="'.$d.'" aria-label="select">';
}

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case object
// parameter names
$columns = array(
	array(
		'db'        => 'id',
		'dt'        => 0
	),
	array(
		'db'        => 'id',
		'dt'        => 1,
		'formatter' => function( $d, $row ) {
			return table_Selector($d);
		}
	),
	array( 'db' => 'user_rid', 'dt' => 2 ),
	array( 'db' => 'file_date',  'dt' => 3 ),
	array( 'db' => 'created_by',   'dt' => 4 ),
	array( 'db' => 'created_on',     'dt' => 5),
	array(
		'db'        => 'id',
		'dt'        => 6,
		'formatter' => function( $d, $row ) {
			return table_actions($d);
		}
	)
);

// SQL server connection information
$sql_details = array(
	'user' => DB_USER,
	'pass' => DB_PASSWORD,
	'db'   => DB_NAME,
	'host' => DB_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */

require( 'ssp.class.php' );

echo json_encode(
	SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);
