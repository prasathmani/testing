<?php
session_start();
require_once '../config/config.php';
require_once '../includes/auth_validate.php';
$db = getDbInstance();

// DB table to use
$table = 'users';

// Table's primary key
$primaryKey = 'id';

function table_actions($d) {
	return '<a href="user-edit.php?user_id='.$d.'&operation=edit" class="btn btn-primary" style="margin-right: 8px;"><i class="fas fa-pen-square"></i></a>';
}

function table_Selector($d) {
	return '<input class="form-check-input position-static ml-0" type="checkbox" name="uid[]" id="'.mt_rand(100000,999999).'" value="'.$d.'" aria-label="select">';
}

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case object
// parameter names
$columns = array(
	array(
		'db'        => 'id',
		'dt'        => 0
	),
	array(
		'db'        => 'id',
		'dt'        => 1,
		'formatter' => function( $d, $row ) {
			return table_Selector($d);
		}
	),
	array( 'db' => 'request_number', 'dt' => 2 ),
	array( 'db' => 'year',  'dt' => 3 ),
	array( 'db' => 'password',   'dt' => 4 ),
	array( 'db' => 'created_at',     'dt' => 5),
	array(
		'db'        => 'id',
		'dt'        => 6,
		'formatter' => function( $d, $row ) {
			return table_actions($d);
		}
	)
);

// SQL server connection information
$sql_details = array(
	'user' => DB_USER,
	'pass' => DB_PASSWORD,
	'db'   => DB_NAME,
	'host' => DB_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */

require( 'ssp.class.php' );

echo json_encode(
	SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);
