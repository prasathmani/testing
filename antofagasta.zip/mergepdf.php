<?php
include './admin/lib/PDFMerger.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	$pdf = new PDFMerger;
	foreach($_REQUEST["filename"] as $file) {
	    try
		{
		    $pdf->addPDF($file, 'all');
		} catch(ExampleException $e) {
		    echo "error";
		}
	}

	try
	{
		$pdf->merge('file', 'uploads/temp/print.pdf'); // generate the file
		echo "success";
		// $pdf->merge('download', 'samplepdfs/test.pdf'); // force download
		// REPLACE 'file' WITH 'browser', 'download', 'string', or 'file' for output options

	} catch(ExampleException $e) {
	    echo "error";
	}
}

?>