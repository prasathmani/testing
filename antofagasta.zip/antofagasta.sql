-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 27, 2019 at 11:58 AM
-- Server version: 5.7.26-0ubuntu0.18.04.1
-- PHP Version: 7.2.17-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `antofagasta`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `series_id` varchar(60) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `admin_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `user_name`, `passwd`, `series_id`, `remember_token`, `expires`, `admin_type`) VALUES
(1, 'admin', '$2y$10$/K.hjNr84lLNDt8fTXjoI.DBp6PpeyoJ.mGwrrLuCZfAwfSAGqhOW', '', '', '2019-06-01 07:10:30', 'admin'),
(2, 'root', '$2y$10$c6Lu9hAlIE/fzhJUklw.T.D/EM66VxfISYZM.6x2r3y48qw/VIxSW', '', '', '2019-06-24 00:00:00', 'super');

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE `meta` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meta`
--

INSERT INTO `meta` (`id`, `name`, `value`, `status`) VALUES
(1, 'login_left_clm_1', '                                                        &lt;section class=&quot;pb_cover_v3 overflow-hidden cover-bg-indigo cover-bg-opacity text-left pb_gradient_v1&quot; id=&quot;section-home&quot;&gt;\n  &lt;div class=&quot;container&quot;&gt;\n    &lt;div class=&quot;row align-items-center justify-content-center&quot;&gt;\n      &lt;div class=&quot;col-md-6&quot;&gt;\n        &lt;h2 class=&quot;heading mb-3&quot;&gt;Instrucciones&lt;/h2&gt;\n        &lt;div class=&quot;sub-heading&quot;&gt;\n          &lt;p class=&quot;mb-4&quot;&gt;Ingrese el n&uacute;mero de petici&oacute;n, luego su rut completo sin puntos, ejemplo: 12678987-4 y el a&ntilde;o del ex&aacute;men, luego dar click en Ingresar para visualizar sus ex&aacute;menes y descargarlos.&lt;/p&gt;\n        &lt;/div&gt;\n      &lt;/div&gt;\n      &lt;div class=&quot;col-md-1&quot;&gt;\n      &lt;/div&gt;\n      &lt;div class=&quot;col-md-5 relative align-self-center&quot;&gt;\n\n        &lt;form class=&quot;bg-white rounded pb_form_v1&quot; method=&quot;POST&quot; action=&quot;authenticate.php&quot;&gt;\n          &lt;h2 class=&quot;mb-4 mt-0 text-center&quot;&gt;Descargue sus Ex&aacute;menes&lt;/h2&gt;\n          &lt;div class=&quot;form-group&quot;&gt;\n            &lt;input type=&quot;text&quot; class=&quot;form-control pb_height-50 reverse&quot; name=&quot;request_number&quot; placeholder=&quot;N&Uacute;MERO DE SOLICITUD&quot; required=&quot;required&quot;&gt;\n          &lt;/div&gt;\n          &lt;div class=&quot;form-group&quot;&gt;\n            &lt;input type=&quot;text&quot; name=&quot;password&quot; class=&quot;form-control pb_height-50 reverse&quot; placeholder=&quot;RODERA&quot; required=&quot;required&quot;&gt;\n          &lt;/div&gt;\n          &lt;div class=&quot;form-group&quot;&gt;\n            &lt;div class=&quot;pb_select-wrap&quot;&gt;\n              &lt;select class=&quot;form-control pb_height-50 reverse&quot; required=&quot;required&quot; name=&quot;year&quot;&gt;\n                &lt;option value=&quot;&quot;&gt;A&Ntilde;O&lt;/option&gt;\n                {{SELECT_YEAR}}\n              &lt;/select&gt;\n            &lt;/div&gt;\n          &lt;/div&gt;\n          &lt;div class=&quot;form-group&quot;&gt;\n          {{ERROR_TXT}}\n        &lt;/div&gt;\n          &lt;div class=&quot;form-group pt-4 pb-4&quot;&gt;\n            &lt;input type=&quot;submit&quot; class=&quot;btn btn-primary btn-lg btn-block pb_btn-pill  btn-shadow-blue&quot; value=&quot;Ingresar&quot;&gt;\n          &lt;/div&gt;\n        &lt;/form&gt;\n\n      &lt;/div&gt;\n    &lt;/div&gt;\n  &lt;/div&gt;\n&lt;/section&gt;                                                                                                                                                                        ', 1),
(2, 'site_title', 'Laboratorio Luis Pasteur Antofagasta', 1),
(3, 'login_footer', '                                                                                                                &lt;footer class=&quot;pb_footer bg-light&quot; role=&quot;contentinfo&quot;&gt;\n  &lt;div class=&quot;container&quot;&gt;\n    &lt;div class=&quot;row&quot;&gt;\n      &lt;div class=&quot;col text-center&quot;&gt;\n        &lt;p class=&quot;pb_font-14&quot;&gt;&copy; 2019. All Rights Reserved. &lt;br&gt; Laboratorio Clinico &lt;a href=&quot;#/home&quot;&gt;Luis Pasteur&lt;/a&gt;&lt;/p&gt;\n      &lt;/div&gt;\n    &lt;/div&gt;\n  &lt;/div&gt;\n&lt;/footer&gt;                                                                                                ', 1),
(4, 'site_description', 'Descarga de Ex&aacute;menes Cl&iacute;nicos', 1),
(5, 'site_main_logo', 'logo.png', 1),
(6, 'review_head_clm', '&lt;section class=&quot;pb_cover_v3 overflow-hidden cover-bg-indigo cover-bg-opacity text-left pb_gradient_v1&quot; id=&quot;section-home&quot;&gt;\n  &lt;div style=&quot;height: 80px&quot;&gt;&lt;/div&gt;\n  &lt;div class=&quot;container&quot;&gt;\n    &lt;div class=&quot;row align-items-center justify-content-center&quot;&gt;\n      &lt;div class=&quot;col-md-12 text-center&quot;&gt;\n        &lt;h2 class=&quot;heading mb-3&quot;&gt;Instrucciones&lt;/h2&gt;\n        &lt;div class=&quot;sub-heading&quot;&gt;\n          &lt;p class=&quot;mb-5&quot;&gt;Los archivos de los resultados de sus ex&aacute;menes relacionados con su N&uacute;mero de Petici&oacute;n &lt;b&gt;{{REQUEST_NO}}&lt;/b&gt; los encuentra m&aacute;s abajo en formato PDF, debe hacer click en cada archivo donde dice Descargar&amp;nbsp;&lt;/p&gt;\n        &lt;/div&gt;\n      &lt;/div&gt;\n    &lt;/div&gt;\n  &lt;/div&gt;\n&lt;/section&gt;\n                                                                                                                                                                                                                        ', 1),
(7, 'time_zone', 'America/Santiago', 1),
(8, 'upload_path', 'uploads', 1),
(9, 'upload_max_size', '25MB', 1),
(10, 'site_favicon', 'icons8-lab-items-50.png', 1),
(11, 'review_body_clm', '&lt;section class=&quot;pb_section&quot;&gt;\n  &lt;div class=&quot;container&quot;&gt;\n    &lt;div class=&quot;row&quot;&gt;\n        &lt;table class=&quot;table table-bordered bg-white rounded pb_form_v1&quot;&gt;\n          &lt;thead class=&quot;thead-light&quot;&gt;\n            &lt;tr&gt;\n              &lt;th scope=&quot;col&quot;&gt;N&uacute;mero de Petici&oacute;n&lt;/th&gt;\n              &lt;th scope=&quot;col&quot;&gt;Fecha de Ex&aacute;men&lt;/th&gt;\n              &lt;th scope=&quot;col&quot;&gt;Descarga&lt;/th&gt;\n            &lt;/tr&gt;\n          &lt;/thead&gt;\n          &lt;tbody&gt;\n            &lt;!-- {{FILES}} --&gt;\n          &lt;/tbody&gt;\n        &lt;/table&gt;\n    &lt;/div&gt;\n  &lt;/div&gt;\n&lt;/section&gt;                                                                                                                        ', 1),
(12, 'site_keywords', 'Descarga de Ex&aacute;menes Cl&iacute;nicos', 1),
(13, 'site_author', 'CCP Programmers', 1),
(14, 'site_admin_logo', 'logo-sm.png', 1),
(15, 'site_admin_title', 'Antofagasta', 1),
(16, 'site_admin_footer', '&lt;footer class=&quot;footer&quot;&gt;\n      &lt;div class=&quot;container&quot;&gt;\n        &copy; 2019. All Rights Reserved. Laboratorio Clinico &lt;a href=&quot;#&quot;&gt;Luis Pasteur&lt;/a&gt;\n      &lt;/div&gt;\n    &lt;/footer&gt;', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_rid` varchar(255) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_date` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `request_number` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(1) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `meta`
--
ALTER TABLE `meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
