
<fieldset>
<?php
$rut = [];
$cols = Array ("id", "request_number");
$db = getDbInstance();
$users = $db->get ("users", null, $cols);
if ($db->count > 0)
    foreach ($users as $user) { 
        array_push($rut, $user);
    }
?>
    <div class="form-group">
        <label>Request Number *</label>
        <select name="user_rid" class="form-control selectpicker" required>
            <option value="" data-rid="" >-- Select Request Number --</option>
            <?php
            foreach ($rut as $opt) {
                if ($edit && $opt['request_number'] == $review['user_rid']) {
                    $sel = "selected";
                } else {
                    $sel = "";
                }
                echo '<option data-rid="'.$opt['id'].'" value="'.$opt['request_number'].'"' . $sel . '>' . $opt['request_number'] . '</option>';
            }

            ?>
        </select>
        <input type="hidden" id="js-user_id" name="user_id" value="<?php echo $review['user_id']; ?>">
    </div> 

    <div class="form-group">
        <label for="name">Name *</label>
          <input type="text" name="name" pattern="[a-zA-Z0-9\s]+" value="<?php echo $edit ? $review['name'] : ''; ?>" placeholder="Name" class="form-control" required="required" id="name" >
    </div> 

    <div class="form-group">
        <label for="age">Year *</label>
        <input type="number" min="15" max="99" step="1" value="<?php echo $edit ? $review['age'] : ''; ?>" name="age" value="" placeholder="Age" class="form-control" required="required" id="age" pattern= "[0-9]">
    </div> 

    <div class="form-group">
        <label for="dob">Year *</label>
        <div class="input-group date" data-provide="datepicker">
            <input type="text" class="form-control" value="<?php echo $edit ? $review['dob'] : ''; ?>" name="dob" placeholder="DOB" id="dob" required>
            <div class="input-group-addon">
                <span class="glyphicon glyphicon-th"></span>
            </div>
        </div>
    </div>

    <div class="form-group">
        <label>Gender * </label>
        <label class="radio-inline">
        <input type="radio" name="gender" value="male" <?php echo ($edit && $review['gender'] =='male') ? "checked": "" ; ?> required="required"/> Male
        </label>
        <label class="radio-inline">
            <input type="radio" name="gender" value="female" <?php echo ($edit && $review['gender'] =='female')? "checked": "" ; ?> required="required" id="female"/> Female
        </label>
    </div>

    <div class="form-group">
        <label for="physician">Physician *</label>
        <input type="text" name="physician" pattern="[a-zA-Z0-9\s]+" value="<?php echo $edit ? $review['physician'] : ''; ?>" placeholder="Physician" class="form-control" required="required" id="physician" >
    </div>
    <?php if(!$edit) { ?>
    <div class="form-group">
        <label for="file_name">File Upload *</label>
        <input type="file" name="file_name" class="form-control" required="required" id="file_name">
    </div>
    <?php } ?>
    

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-primary" >Submit <span class="glyphicon glyphicon-send"></span></button>
    </div>        
</fieldset>