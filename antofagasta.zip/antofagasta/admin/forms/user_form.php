<fieldset>
    <div class="form-group">
        <label for="request_number">Request Number *</label>
          <input type="text" name="request_number" pattern="[a-zA-Z0-9\s]+" value="<?php echo $edit ? $customer['request_number'] : ''; ?>" placeholder="Request Number" class="form-control" required="required" id="request_number" >
    </div> 

    <div class="form-group">
        <label for="year">Year *</label>
        <input type="number" min="<?php echo date("Y") ?>" max="2030" step="1" value="<?php echo $edit ? $customer['year'] : date("Y"); ?>" name="year" value="" placeholder="year" class="form-control" required="required" id="year" pattern= "[0-9]">
    </div> 

<?php if(!$edit) { ?>
    <div class="form-group">
        <label for="password">Password *</label>
        <input type="password" name="password" pattern="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).*$" value="<?php echo $edit ? $customer['password'] : ''; ?>" placeholder="password" class="form-control" required="required" id="password">
    </div> 
<?php } ?>
    

    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-primary" >Submit <span class="glyphicon glyphicon-send"></span></button>
    </div>        
</fieldset>