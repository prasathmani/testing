<?php
require_once './admin/config/config.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$username = filter_input(INPUT_POST, 'request_number');
	$passwd = filter_input(INPUT_POST, 'password');
	$year = filter_input(INPUT_POST, 'year');

	//Get DB instance.
	$db = getDbInstance();

	$db->where("request_number", $username);

	$row = $db->get('users');

	if ($db->count >= 1) {

		$db_password = $row[0]['password'];
		$user_id = $row[0]['id'];
		$db_year = $row[0]['year'];

		if (md5($passwd) == $db_password && ($year == $db_year)) {

			$_SESSION['review_logged_in'] = TRUE;
			$_SESSION['review_id'] = $user_id;

			//Authentication successfull redirect user
			header('Location:review.php');

		} else {
			$_SESSION['rw_login_failure'] = "Invalid user name or password";
			header('Location:index.php');
		}

		exit;
	} else {
		$_SESSION['rw_login_failure'] = "Invalid user name or password";
		header('Location:index.php');
		exit;
	}

}
else {
	die('Method Not allowed');
}