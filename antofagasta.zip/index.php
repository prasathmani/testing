<?php
session_start();
require_once './admin/config/config.php';
$token = bin2hex(openssl_random_pseudo_bytes(16));
//If User has already logged in, redirect to dashboard page.
if (isset($_SESSION['review_logged_in']) && $_SESSION['review_logged_in'] === TRUE) {
  header('Location:review.php');
}

$db = getDbInstance();
$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$meta = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $meta[$data['name']] = $data['value'];
    }
}

function template($template, $data) {
  if (preg_match_all("/{{(.*?)}}/", $template, $m)) {
    foreach ($m[1] as $i => $varname) {
        $template = str_replace($m[0][$i], sprintf('%s', $data[$varname]), $template);
    }
  }
  return $template;
}

$error_msg = '';          
if (isset($_SESSION['rw_login_failure'])) {
  $error_msg =  '<div class="form-group"><div class="alert alert-danger alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'.$_SESSION['rw_login_failure'].'</div></div>';
   unset($_SESSION['rw_login_failure']);
}

$already_selected_value = date("Y");
$earliest_year = 2030;
$select_year = '';
foreach (range(date('Y'), $earliest_year) as $x) {
    $select_year .= '<option value="'.$x.'"'.($x === $already_selected_value ? ' selected="selected"' : '').'>'.$x.'</option>';
}
 
$data = ['ERROR_TXT' => $error_msg, 'SELECT_YEAR' => $select_year];           
$login_left_clm_1_html = html_entity_decode($meta['login_left_clm_1']);
$login_left_clm_1 = template($login_left_clm_1_html, $data);


?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title><?php echo $meta['site_title']; ?></title>
		<meta name="description" content="<?php echo $meta['site_description']; ?>">

    <link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i,600|Montserrat:200,300,400" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.css">

    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/slick-theme.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing-2.css">
	</head>
	<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <!-- Nav bar -->
    <nav class="navbar navbar-expand-lg navbar-dark pb_navbar pb_scrolled-light" id="pb-navbar">
      <div class="container">
        <a class="navbar-brand" href="/">
          <img src="<?php echo $meta['site_main_logo']; ?>" alt="Logo">
        </a>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#probootstrap-navbar" aria-controls="probootstrap-navbar" aria-expanded="false" aria-label="Toggle navigation">
          <span><i class="ion-navicon"></i></span>
        </button>
      </div>
    </nav>
    <!-- END nav -->


    <!-- Head Section -->
    <?php echo $login_left_clm_1; ?>
    <!-- END section -->

    <!-- Footer -->
    <?php echo html_entity_decode($meta['login_footer']); ?>
    <!-- Footer End -->

    <!-- loader -->
    <div id="pb_loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#1d82ff"/></svg></div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/main.js"></script>
	</body>
</html>
