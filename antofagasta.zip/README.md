# antofagasta
URL: https://laboratoriopasteurantofagasta.cl

## Local
Admin: {path}/admin
Login: root/root@123
