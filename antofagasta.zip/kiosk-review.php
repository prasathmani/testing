<?php
session_start();
require_once './admin/config/config.php';
require_once './auth.php';

$db = getDbInstance();
$db->where("user_id", $_SESSION['review_id']);
$rows = $db->get('reviews');
$reviews = $rows;

$db->where("id", $_SESSION['review_id']);
$users = $db->get('users');
$user = $users[0];

$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$meta = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $meta[$data['name']] = $data['value'];
    }
}

function template($template, $data) {
  if (preg_match_all("/{{(.*?)}}/", $template, $m)) {
    foreach ($m[1] as $i => $varname) {
        $template = str_replace($m[0][$i], sprintf('%s', $data[$varname]), $template);
    }
  }
  return $template;
}

function getFileUrl($file_name) {

    return str_replace('../', '', $file_name);
}

$REQUEST_NO_YEAR = $user['request_number'];
$data = ['REQUEST_NO' => $REQUEST_NO_YEAR];           
$review_header_html = html_entity_decode($meta['review_head_clm']);
$review_header = template($review_header_html, $data);

$review_body_html = html_entity_decode($meta['kiosk_table']);
$review_body_html = str_replace('<!--', '', $review_body_html);
$review_body_html = str_replace('-->', '', $review_body_html);
$review_body_list = "";
foreach ($reviews as $row) {
  $review_body_list .= '<tr><td><div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" name="filename[]" value="'.htmlspecialchars(getFileUrl($row['file_name'])).'" id="customControlAutosizing-'.$row['id'].'" /><label class="custom-control-label" for="customControlAutosizing-'.$row['id'].'"></label></div></td><th scope="row">'.@end((explode('/', $row['file_name']))).'</th><td>'.$row['file_date'].'</td></tr>';
}
$data = ['FILES' => $review_body_list];           
$review_body = template($review_body_html, $data);

?>
<!DOCTYPE html>
<html lang="en">
	<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="<?php echo $meta['site_description']; ?>">
      <meta name="keywords" content="<?php echo $meta['site_keywords']; ?>">
      <meta name="author" content="<?php echo $meta['site_author']; ?>">
      <link rel="icon" type="image/png" href="<?php echo 'uploads/assets/'.$meta['site_favicon']; ?>" />

      <title><?php echo $meta['site_title']; ?></title>

      <link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i,600|Montserrat:200,300,400" rel="stylesheet">
      <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.css">

      <link rel="stylesheet" href="assets/css/slick.css">
      <link rel="stylesheet" href="assets/css/slick-theme.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/landing-2.css">
      <link rel="stylesheet" type="text/css" href="assets/css/print.min.css">
	</head>
	<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <!-- Nav bar -->
    <nav class="navbar navbar-expand-lg navbar-dark pb_navbar pb_scrolled-light" id="pb-navbar">
      <div class="container">
        <a class="navbar-brand" href="/">
          <img src="<?php echo 'uploads/assets/'.$meta['site_main_logo']; ?>" alt="Logo">
        </a>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#probootstrap-navbar" aria-controls="probootstrap-navbar" aria-expanded="false" aria-label="Toggle navigation">
          <span><i class="ion-navicon"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="probootstrap-navbar">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item cta-btn ml-xl-2 ml-lg-2 ml-md-0 ml-sm-0 ml-0"><a class="nav-link" href="logout.php?kiosk=true"><span class="pb_rounded-4 px-4">Cerrar Sesión</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->


    <?php echo $review_header; ?>
    <?php echo $review_body; ?>
    <!-- END section -->

    <!-- Modal -->
    <div class="modal fade" id="printModal" tabindex="-1" role="dialog" aria-labelledby="printModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="printModalLabel">Impreso exitosamente</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            El trabajo de impresión se ha enviado a la impresora, compruebe la impresora.
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">Cerca</button>
          </div>
        </div>
      </div>
    </div>



    <!-- loader -->
    <div id="pb_loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#1d82ff"/></svg></div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/print.min.js"></script>
    <script>
      function get_checkboxes() { for (var e = document.getElementsByName("filename[]"), t = [], n = e.length - 1; n >= 0; n--) (e[n].type = "checkbox") && t.push(e[n]); return t }
      function change_checkboxes(e, t) { for (var n = e.length - 1; n >= 0; n--) e[n].checked = "boolean" == typeof t ? t : !e[n].checked }

      function select_all() { change_checkboxes(get_checkboxes(), !0) }
      function unselect_all() { change_checkboxes(get_checkboxes(), !1) }
      function checkbox_value() { 
          var _e = get_checkboxes();
          var formData = [];
          if(_e.length > 0) {
              _e.forEach(function(input){
                  if(input.checked) {
                      formData.push({name:input.name,value:input.value});
                  }
              });
          }
          return formData;
      }

      $("#customControlAutosizing").on("change", function(){
          if($(this).is(":checked")) {
              select_all();
          } else {
              unselect_all();
          }
      });

      function printGenerator(data) {
        $.ajax({
            type: "POST",
            data: data,
            url: 'mergepdf.php',
            success: function(response){
                if(response == "success") {
                    PrintAll();
                    $('#printModal').modal('show');
                } else {
                    alert('Error! intente nuevamente');
                }
            }
          });
      }

      function PrintAll(pages) {
          var path = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
          path = path + '/uploads/temp/print.pdf';
          printJS({printable:path, type:'pdf'})
      }

      $("#js-print").on("click", function(e){
        e.preventDefault();
        var selected = checkbox_value();
        if(selected && selected.length) {
          var _selected = [];
          for(let i = 0; i < selected.length; i++){
             _selected.push(selected[i].value);
          }

          printGenerator(selected)
        }
      })
    </script>
	</body>
</html>
