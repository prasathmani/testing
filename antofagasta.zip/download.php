<?php
$file = $_REQUEST["f"];
$file_path = 'admin/'.$_REQUEST["f"];
// Quick check to verify that the file exists

if( !file_exists($file_path) ) die("File not found");
// Force the download
header('Content-Disposition: attachment; filename="'.basename($file_path).'"');
header("Content-Length: " . filesize($file_path));
header("Content-Type: application/octet-stream;");
readfile($file_path);
?>