<?php
session_start();
require_once './admin/config/config.php';
require_once './auth.php';

$db = getDbInstance();
$db->where("user_id", $_SESSION['review_id']);
$rows = $db->get('reviews');
$reviews = $rows;

$db->where("id", $_SESSION['review_id']);
$users = $db->get('users');
$user = $users[0];

$cols = Array ("name", "value");
$metas = $db->get ("meta", null, $cols);
$meta = [];
if ($db->count > 0) {
    foreach ($metas as $data) {
        $meta[$data['name']] = $data['value'];
    }
}

function template($template, $data) {
  if (preg_match_all("/{{(.*?)}}/", $template, $m)) {
    foreach ($m[1] as $i => $varname) {
        $template = str_replace($m[0][$i], sprintf('%s', $data[$varname]), $template);
    }
  }
  return $template;
}

function getFileUrl($file_name) {
    return str_replace('../', '', $file_name);
}

$REQUEST_NO_YEAR = $user['request_number'];
$data = ['REQUEST_NO' => $REQUEST_NO_YEAR];           
$review_header_html = html_entity_decode($meta['review_head_clm']);
$review_header = template($review_header_html, $data);

$review_body_html = html_entity_decode($meta['review_body_clm']);
$review_body_html = str_replace('<!--', '', $review_body_html);
$review_body_html = str_replace('-->', '', $review_body_html);
$review_body_list = "";
foreach ($reviews as $row) {
  $review_body_list .= '<tr><th scope="row">'.@end((explode('/', $row['file_name']))).'</th><td>'.$row['file_date'].'</td><td><a href="'.htmlspecialchars(getFileUrl($row['file_name'])).'" download>Descargar</a></td></tr>';
}
$data = ['FILES' => $review_body_list];           
$review_body = template($review_body_html, $data);

?>
<!DOCTYPE html>
<html lang="en">
	<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="<?php echo $meta['site_description']; ?>">
      <meta name="keywords" content="<?php echo $meta['site_keywords']; ?>">
      <meta name="author" content="<?php echo $meta['site_author']; ?>">
      <link rel="icon" type="image/png" href="<?php echo 'uploads/assets/'.$meta['site_favicon']; ?>" />

      <title><?php echo $meta['site_title']; ?></title>

      <link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i,600|Montserrat:200,300,400" rel="stylesheet">
      <link rel="stylesheet" href="assets/css/bootstrap/bootstrap.css">

      <link rel="stylesheet" href="assets/css/slick.css">
      <link rel="stylesheet" href="assets/css/slick-theme.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/landing-2.css">
	</head>
	<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <!-- Nav bar -->
    <nav class="navbar navbar-expand-lg navbar-dark pb_navbar pb_scrolled-light" id="pb-navbar">
      <div class="container">
        <a class="navbar-brand" href="/">
          <img src="<?php echo 'uploads/assets/'.$meta['site_main_logo']; ?>" alt="Logo">
        </a>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#probootstrap-navbar" aria-controls="probootstrap-navbar" aria-expanded="false" aria-label="Toggle navigation">
          <span><i class="ion-navicon"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="probootstrap-navbar">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item cta-btn ml-xl-2 ml-lg-2 ml-md-0 ml-sm-0 ml-0"><a class="nav-link" href="logout.php"><span class="pb_rounded-4 px-4">Cerrar Sesión</span></a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->


    <?php echo $review_header; ?>
    <?php echo $review_body; ?>
    <!-- END section -->

    <!-- Footer -->
    <?php echo html_entity_decode($meta['login_footer']); ?>
    <!-- Footer End -->

    <!-- loader -->
    <div id="pb_loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#1d82ff"/></svg></div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/main.js"></script>
	</body>
</html>
