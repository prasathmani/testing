<?php
session_start();
require_once './admin/config/config.php';
$token = bin2hex(openssl_random_pseudo_bytes(16));
//If User has already logged in, redirect to dashboard page.
if (isset($_SESSION['review_logged_in']) && $_SESSION['review_logged_in'] === TRUE) {
  header('Location:review.php');
}

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>Laboratorio Luis Pasteur Antofagasta</title>
		<meta name="description" content="Laboratorio Luis Pasteur Antofagasta">
		<meta name="keywords" content="Laboratorio Luis Pasteur Antofagasta">

    <link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i,600|Montserrat:200,300,400" rel="stylesheet">
		<link rel="stylesheet" href="assets/css/bootstrap/bootstrap.css">

    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/slick-theme.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/landing-2.css">
	</head>
	<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <!-- Nav bar -->
    <nav class="navbar navbar-expand-lg navbar-dark pb_navbar pb_scrolled-light" id="pb-navbar">
      <div class="container">
        <a class="navbar-brand" href="/">
          <img src="assets/images/logo.png" alt="Logo">
        </a>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#probootstrap-navbar" aria-controls="probootstrap-navbar" aria-expanded="false" aria-label="Toggle navigation">
          <span><i class="ion-navicon"></i></span>
        </button>
      </div>
    </nav>
    <!-- END nav -->


    <section class="pb_cover_v3 overflow-hidden cover-bg-indigo cover-bg-opacity text-left pb_gradient_v1 pb_slant-light" id="section-home">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-6">
            <h2 class="heading mb-3">Laboratorio Luis Pasteur</h2>
            <div class="sub-heading">
              <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
              <p class="mb-5"><a class="btn btn-success btn-lg pb_btn-pill smoothscroll" href="#section-pricing"><span class="pb_font-14 text-uppercase pb_letter-spacing-1">Go to Main Site</span></a></p>
            </div>
          </div>
          <div class="col-md-1">
          </div>
          <div class="col-md-5 relative align-self-center">

            <form class="bg-white rounded pb_form_v1" method="POST" action="authenticate.php">
              <h2 class="mb-4 mt-0 text-center">Sign In</h2>
              <div class="form-group">
                <input type="text" class="form-control pb_height-50 reverse" name="request_number" placeholder="REQUEST NUMBER" required="required">
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control pb_height-50 reverse" placeholder="RUT" required="required">
              </div>
              <div class="form-group">
                <div class="pb_select-wrap">
                  <select class="form-control pb_height-50 reverse" required="required" name="year">
                    <option value="">YEAR</option>
                    <option value="2019">2019</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
              <?php
              if (isset($_SESSION['rw_login_failure'])) {?>
                  <div class="alert alert-danger alert-dismissable">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <?php echo $_SESSION['rw_login_failure'];unset($_SESSION['rw_login_failure']); ?>
                  </div>
              <?php }?>
            </div>
              <div class="form-group pt-4 pb-4">
                <input type="submit" class="btn btn-primary btn-lg btn-block pb_btn-pill  btn-shadow-blue" value="Ingresar">
              </div>
            </form>

          </div>
        </div>
      </div>
    </section>
    <!-- END section -->

    <!-- Footer -->
    <footer class="pb_footer bg-light" role="contentinfo">
      <div class="container">
        <div class="row">
          <div class="col text-center">
            <p class="pb_font-14">&copy; 2019. All Rights Reserved. <br> Laboratorio Clinico  <a href="#/home">Luis Pasteur</a></p>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer End -->

    <!-- loader -->
    <div id="pb_loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#1d82ff"/></svg></div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/main.js"></script>
	</body>
</html>
