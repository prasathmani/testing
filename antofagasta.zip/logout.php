<?php
require_once './admin/config/config.php';
session_start();
session_destroy();
if(isset($_REQUEST["kiosk"])) {
	header('Location:kiosk.php');
} else {
	header('Location:index.php');	
}
exit;

 ?>